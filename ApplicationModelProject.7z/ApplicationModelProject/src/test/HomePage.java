package test;

import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.web.*;

public class HomePage extends AbstructPageLoaderDriver {

//Liens Artisans    		
    LinkDescription artisan_link = new LinkDescription.Builder()
    		.tagName("A")
    		.innerText("Artisans").build();
    
//Liens Logout    
    WebElementDescription logout_elemD = new WebElementDescription.Builder()
    		.tagName("A")
    		.innerText(" Logout ").build();


    public HomePage(Browser browser){
        super(browser);
    }

    public Boolean isLoggedIn() throws GeneralLeanFtException {  
        Link artisan_link_menu = browser.describe(Link.class, artisan_link);
        artisan_link_menu.highlight();
        if (artisan_link_menu.exists(10)) return true;
        else return false;
    }

    public HomePage clickLogoutbtn() throws GeneralLeanFtException {
	  WebElement logout_elem = browser.describe(WebElement.class, logout_elemD);
      logout_elem.highlight();
      logout_elem.click();      		
      return new HomePage(browser);

    }



}

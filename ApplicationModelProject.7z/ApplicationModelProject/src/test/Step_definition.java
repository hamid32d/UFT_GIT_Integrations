package test;
import org.junit.Assert;
import com.hp.lft.sdk.web.Browser;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Step_definition {

    Browser browser;
    LoginPage page=new LoginPage(browser);
    HomePage homepage=new HomePage(browser);

    @Given("^open Internet Explorer and navigate to Bricall page$")
    public void open_Internet_Explorer_and_navigate_to_Bricall_page() throws Throwable {
        page.setBrowser();
        page.syncBrowser();
    }

    @When("^User logs in using username as \"([^\"]*)\" and password as \"([^\"]*)\"$")
    public void user_logs_in_using_username_as_and_password_as(String arg1, String arg2) throws Throwable {
        page.setUsername(arg1);
        page.setPassword(arg2);
        page.clickLoginBtn();
        page.setSecurityWindows2();
        page.syncBrowser();
    }

    @Then("^login should be successful$")
    public void login_should_be_successful() throws Throwable {
        Boolean is_login_value = homepage.isLoggedIn();
        Assert.assertEquals(true,is_login_value);
    }

    @Then("^User presses Sign Out button$")
    public void user_presses_Sign_Out_button() throws Throwable {
        homepage.clickLogoutbtn();
        page.closeDriver();
    }

}

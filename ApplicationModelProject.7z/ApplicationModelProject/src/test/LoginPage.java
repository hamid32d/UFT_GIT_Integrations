package test;

import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.web.*;

public class LoginPage extends AbstructPageLoaderDriver  {
	
    //user
    EditFieldDescription txt_userName =  new EditFieldDescription.Builder().type("text").tagName("INPUT").name("user").build();
    
    //password
    EditFieldDescription txt_password =  new EditFieldDescription.Builder().type("password").tagName("INPUT").name("password").build();
    
    //Se connecter 
    ButtonDescription button_SihnIn = new ButtonDescription.Builder().buttonType("submit").tagName("BUTTON").name(" Se connecter ").build();
    
    public LoginPage(Browser browser){
        super(browser);
    }

    public LoginPage setUsername(String userName)  throws GeneralLeanFtException{
    	  EditField usernameField = browser.describe(EditField.class, txt_userName);
	      usernameField.setValue(userName);
	      return  new LoginPage(browser);
    }

    public LoginPage setPassword(String password) throws GeneralLeanFtException {
    	  EditField passWordField = browser.describe(EditField.class, txt_password);
	      passWordField.setValue(password);
	      return new LoginPage(browser);
    }

    public LoginPage clickLoginBtn() throws GeneralLeanFtException {
    	  Button signIn = browser.describe(Button.class, button_SihnIn);
          signIn.click();
          return new LoginPage(browser);
    }

}

package test;

import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.ModifiableSDKConfiguration;
import com.hp.lft.sdk.SDK;
import com.hp.lft.sdk.web.Browser;
import com.hp.lft.sdk.web.BrowserDescription;
import com.hp.lft.sdk.web.BrowserFactory;
import com.hp.lft.sdk.web.BrowserType;
import java.net.URI;


public class AbstructPageLoaderDriver {

    protected  static Browser browser;
    public AbstructPageLoaderDriver(Browser browser){
    	AbstructPageLoaderDriver.browser=browser;
    }

    public void setBrowser() throws Exception {
        ModifiableSDKConfiguration config = new ModifiableSDKConfiguration();
        config.setServerAddress(new URI("ws://localhost:5095"));
        SDK.init(config);

//      browser= BrowserFactory.launch(BrowserType.INTERNET_EXPLORER);
        browser= BrowserFactory.attach(new BrowserDescription.Builder()
	    		 .type(BrowserType.INTERNET_EXPLORER).build());

    }
    public void setSecurityWindows1() throws Exception {
    
    	ApplicationModel appModel = new ApplicationModel(browser);
		if (appModel.SCuritDeWindowsDialog().exists(16)) {
			appModel.SCuritDeWindowsDialog().highlight();
			System.out.println("La fen�tre de s�curit� Windows_Echonet s'affiche");
			appModel.SCuritDeWindowsDialog().WinEditEditField().setText("c31833");
			appModel.SCuritDeWindowsDialog().WinEditEditField1().setText("XXXX");
			appModel.SCuritDeWindowsDialog().OKButton().click();
			
		}

    } 
    
    public void setSecurityWindows2() throws Exception {
    	
    	ApplicationModel appModel = new ApplicationModel(browser);
		if (appModel.SCuritDeWindowsDialog().exists(20)) {
			appModel.SCuritDeWindowsDialog().highlight();
			System.out.println("La fen�tre de s�curit� Windows_Bricall s'affiche");
			appModel.SCuritDeWindowsDialog().WinEditEditField().setText("admin");
			appModel.SCuritDeWindowsDialog().WinEditEditField1().setText("secret");
			appModel.SCuritDeWindowsDialog().OKButton().click();
		}

    } 
    
    public LoginPage PageNavigateToWebApp(String url) throws GeneralLeanFtException {
        browser.navigate(url);
        return new LoginPage(browser);
    }

    public void syncBrowser() throws GeneralLeanFtException {
        browser.sync();
    }

    public void closeDriver(){
        System.out.println("This step will close and cleanup the browser");
        try {
            browser.close();
        } catch (GeneralLeanFtException e) {
            System.out.println("browser is already closed");
        }
    }

}
